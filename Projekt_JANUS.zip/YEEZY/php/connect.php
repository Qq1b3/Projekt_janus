<?php
########################################
### pripojenie do databazy #############
### subor sluzi na pripojenie do DB ####
########################################

$mysql_server="localhost";
$mysql_user="root";
$mysql_pass="";
$mysql_dbs="yeezy";

$sqlcon = mysqli_connect($mysql_server, $mysql_user, $mysql_pass, $mysql_dbs);

########################################
### nastavenie stredoeuropskeho kodovania
### je to potrebne, aby DB server vracal poziadavky v tomto kodovani
########################################
$result = mysqli_set_charset($sqlcon,"utf8");

if (!$result)	die ('Nastala chyba pri pripojeni DB serveru.');

?>