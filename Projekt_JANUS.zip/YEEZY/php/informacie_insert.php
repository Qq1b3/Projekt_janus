<?php
########################################
### include suboru pre pripojenie do DB
########################################
include ('connect.php');


?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="description" content="yeezy">
	<meta name="keywords" content="topanky, obuv, yeezy, Kanye West, Adidas">
  	<meta name="author" content="Jozef Janus">
    <title>YEEZY</title>
	<link rel="shortcut icon" type="image/png" href="../img/yeezy_icon.png">
    <link rel="stylesheet" href="../css/style.css">
	<link rel="stylesheet" href="../css/slider1.css">
  </head>
  <body>
        <header>
		<div class="wrap1">
		<div class="container">
        <div id="logo">
          <img src="../img/logo_adidas.png">
        </div>
		<div class="container">
		<div id="logo2">
		<img src="../img/cc.png">
		</div>
		</div>
		 </div>
		 <div class="wrap2">
        <nav>
          <ul>
            <li><a href="../index.html">Domov</a></li>
            <li><a href="../yeezy.html">Yeezy</a></li>
            <li class="current"><a href="../sluzby.html">Sluzby</a></li>
			<li><a href="../kontakt.html">Kontakt</a></li>
          </ul>
        </nav>
      </div>
</div>
    </header>
	
<h1>Spracovanie </h1>
<?php

$sql="INSERT INTO informacie (meno,email,produkt,komentar)
	  VALUES('$_POST[meno]','$_POST[email]','$_POST[produkt]','$_POST[komentar]')"; 
$vysledok = mysqli_query($sqlcon,$sql); // vysledok dotaz


if ($vysledok){
	echo "<p> Ďakujeme za otázku. </p>";
	echo "<p><a href='../sluzby.html'>Ďalej ...</a></p>";
}
else {
	echo "<p>Nastala chyba.</p>";
	echo "<p><a href='../sluzby.html'>Ďalej ...</a></p>";
}

?>
<footer>
      
	  <section id="novinky">
      <div class="container">
        <h1>Prihláste sa na odber noviniek!</h1>
        <form>
          <input type="email" placeholder="Zadaj svoj email..." class="kolonka1 ">
          <button type="submit" class="button1">Odoberať!</button>
        </form>
      </div>
	  <p>Jozef Janus, Copyright &copy; 2019</p>
    </section>
    </footer>
  </body>
</html>
