<?php
########################################
### include suboru pre pripojenie do DB
########################################
include ('connect.php');
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="description" content="yeezy">
	<meta name="keywords" content="topanky, obuv, yeezy, Kanye West, Adidas">
  	<meta name="author" content="Jozef Janus">
    <title>YEEZY</title>
	<link rel="shortcut icon" type="image/png" href="../img/yeezy_icon.png">
    <link rel="stylesheet" href="../css/style.css">
	<link rel="stylesheet" href="../css/slider1.css">
  </head>
  <body>
  <?php
// zadefinovanie premenných a nastavenie ich ako prázdne
$menoErr = $emailErr = $komntErr= "";
$meno = $email = $komentar =$cistenie = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") 
{
	if (empty($_POST["meno"])) { $menoErr = "Meno je vyzadované"; } 
    else 
	{ 
	$meno = test_input($_POST["meno"]);  
	// otestuje či meno obsahuje písmená a medzery
		if (!preg_match("/^[a-zA-Z ]*$/",$meno)) 
		{ $menoErr = "Iba písmená a medzery sú povolené!";  }	
	}
	
	if (empty($_POST["email"])) { $emailErr = "Email je vyzadovaný"; }
	else {
    $email = test_input($_POST["email"]);
    // kontroluje či má email platný tvar
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) 
		{	$emailErr = "Nesprávný zápis emailovej adresy";	}	}
	
    
	
	if (empty($_POST["komentar"])) { $produkt = ""; } 
	else { $komentar = test_input($_POST["komentar"]); }

	
	
	
}

function test_input($data) {
   $data = trim($data); 		// vymaze prazdne znaky alebo ine preddefinovane znaky
   $data = stripslashes($data); //vymaze vsetky spatne lomitka z retazca
   $data = htmlspecialchars($data); // vymaze vyznam znakov "<" ">" aby nebolo mozne vlozit html alebo iny prikaz
   return $data; }
   
         ?>
		 
      <header>
		<div class="wrap1">
		<div class="container">
        <div id="logo">
          <img src="../img/logo_adidas.png">
        </div>
		<div class="container">
		<div id="logo2">
		<img src="../img/cc.png">
		</div>
		</div>
		 </div>
		 <div class="wrap2">
        <nav>
          <ul>
            <li><a href="../index.html">Domov</a></li>
            <li><a href="../yeezy.html">Yeezy</a></li>
            <li class="current"><a href="../sluzby.html">Sluzby</a></li>
			<li><a href="../kontakt.html">Kontakt</a></li>
          </ul>
        </nav>
      </div>
</div>
    </header>

	<div class="wrap">
	<div class="stlpec_vlavo">
	<img src="../img/clean_hover.png" width="200" height="200" border="0">
	<br>
	<p>
	<a href="../sluzby.html">
	<img class="mensi" src="../img/reply.png" width="50" height="50" border="0">
	</a>
	</p>
	</div>
	
	<div class="obsah_vpravo">
	<h1>Máte záujem o profesionálne cistenie topánok? Napíste nám!</h1>
	<form enctype="multipart/form-data" method="post" action="clean_insert.php" >

	<span class="zvyraznene">Tvoje meno: </span><input type="text" name="meno" placeholder="Zadaj svoje meno..." class="kolonka1 input_box1"><span class="error">* <?php echo $menoErr;?></span><br><br>
	<span class="zvyraznene">Email: </span><span class="input_box"> <input type="text" name="email" placeholder="Zadaj svoj email..." class="kolonka1 input_box2"><span class="error">* <?php echo $emailErr;?></span></span><br><br>
	<span class="zvyraznene">Druh cistenia: </span><select name="cistenie" id="cistenie" class="kolonka1 input_box5">
				<option value="hlbkove">Hĺbkové</option>
				<option value="povrchove">Povrchové</option>
			</select><br><br>
	<span class="zvyraznene">Komentár: </span><textarea name="komentar" rows="5" cols="40" placeholder="Zacni písat svoj komentár..."class="kolonka1 input_box6"></textarea><br>
	<p><span class="error malicke">* vyzadované polia</span></p>
	<button type="submit" name="submit" class="button1">Odoslat!</button>
	<input type='hidden' name='cleanID' id='cleanID' value=''>
</form>


	</div>
	</div>
	  <footer>
      
	  <section id="novinky">
      <div class="container">
        <h1>Prihláste sa na odber noviniek!</h1>
        <form>
          <input type="email" placeholder="Zadaj svoj email..." class="kolonka1 ">
          <button type="submit" class="button1">Odoberať!</button>
        </form>
      </div>
	  <p>Jozef Janus, Copyright &copy; 2019</p>
    </section>
    </footer>
  </body>
</html>
